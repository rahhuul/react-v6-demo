import React, { useState } from 'react';
import { Col, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { FaTimesCircle, FaCheckCircle, FaSignOutAlt, FaEdit } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import { UserSelector, clearMessage, verifyMail, logOut, updateUser } from '../../store/reducers/userSlice';
import { Modal, Button, Checkbox, Form, Input, notification } from 'antd';


const ProfileFrom = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [api, contextHolder] = notification.useNotification();
    const { user_id, name, busd_address, email, email_verified } = useSelector(UserSelector);

    const updateProfile = (values) => {
        values.user_id = user_id;
        dispatch(updateUser(values));
        openNotification("success", "Profile Update successfully !");
    };

    const onFinishFailedLogin = (errorInfo) => {
    };

    const openNotification = (type, msg) => {
        api[type]({
            message: msg,
            duration: 1.5,
        });
    }

    const logoutClick = () => {
        dispatch(logOut());
        navigate('/');
    };

    return (
        <>
            {contextHolder}
            <Form name="basic"
                onFinish={updateProfile}
                onFinishFailed={onFinishFailedLogin}
                initialValues={{ name: name, busd_address: busd_address, email: email }}
                autoComplete="off"
            >
                <Row>
                    <Col md="12">
                        <div className='profile_bg'>
                            <Form.Item
                                name="name"
                                rules={[{ required: true, message: 'Please Enter your name!' }]}
                            >
                                <Input placeholder="Enter your name" defaultValue={name} />
                            </Form.Item>
                            {/* <span className='verify-success'>
                                <FaCheckCircle />
                            </span>
                            <span className='verify-false'>
                                <FaTimesCircle />
                            </span> */}
                        </div>
                    </Col>
                    <Col md="12">
                        <div className='profile_bg'>
                            {/* <input type="text" name="username" defaultValue="0x52199744e7aa58009ae7b347ACC7EdEfe545c15a" /
                             */}
                            <Form.Item
                                name="busd_address"
                            >
                                <Input placeholder="Enter your BUSD Address" defaultValue={busd_address} />
                            </Form.Item>
                            {/* <span className='verify-success'>
                                <FaCheckCircle />
                            </span>
                            <span className='verify-false'>
                                <FaTimesCircle />
                            </span> */}
                        </div>
                    </Col>
                    <Col md="12">
                        <div className='profile_bg'>
                            {/* <input className='margin-bottom' type="email" name="username" defaultValue="push@gmail.com" /> */}

                            <Form.Item
                                name="email"
                                rules={[{ required: true, message: 'Please Enter your email!' }]}
                            >
                                <Input placeholder='email@example.com' defaultValue={email} />
                            </Form.Item>
                            {/* <span className='verify-success'>
                                <FaCheckCircle />
                            </span>
                            <span className='verify-false'>
                                <FaTimesCircle />
                            </span> */}
                        </div>
                        {
                            email_verified != 1 &&
                                <div className="email_noti">
                                    <a className="resend_mail active" href="/raffle">Resend Verification Mail</a>
                                </div>
                        }
                    </Col>
                </Row>


                <div className='btn_wrapp'>
                    <Row>
                        <Col md="6">
                            {/* <button onClick={updateProfile} ><FaEdit /> Update Profile</button> */}

                            <button type='submit'><FaEdit />Update Profile</button>
                        </Col>
                        <Col md="6">
                            <button onClick={logoutClick}><FaSignOutAlt /> Log Out</button>
                        </Col>
                    </Row>
                </div>

            </Form>

        </>
    )
}
export default ProfileFrom;