import React from 'react';
import { Row, Col } from 'react-bootstrap';

import ActivityRegister from './ActivityRegister'

const ActivityMain = () => {
    return (

        <Row className='justify-content-center'>
            <Col md="10" lg="9" xl="8">
                <div className='main_heading text-center'>
                    <h1>Activity</h1>
                    <p>You can find out about the ongoing raffle registration here. You can check out which raffles are currently getting a lot of registration here. Follow us on Twitter and join Discord for more information.</p>
                </div>
            </Col>

            <ActivityRegister />

        </Row>

    )
}

export default ActivityMain;