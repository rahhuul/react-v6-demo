import React from 'react';
import { Col } from 'react-bootstrap';

import { FaCheckCircle, FaCalendarAlt, FaWallet, FaEthereum, FaUserAlt, FaTicketAlt, FaTrophy } from "react-icons/fa";
import { NavLink } from 'react-router-dom';

const ActivityRegister = () => {
    return (

        <Col md="12">
            <div className='register_bg d-flex align-items-center flex-md-row flex-column'>
                <div className='register_img'>
                    <img src={require('../../assets/imgs/10ETH.png')} alt="10ETH" />
                </div>
                <div className='register_content'>
                    <p><FaCalendarAlt /> March 01, 2023, 05:00 a.m.</p>
                    <h5>Registered for 10 ETH Raffle <FaCheckCircle /></h5>
                    <ul>
                        <li><FaWallet /> Wallet : <span>0x5219...c15a</span></li>
                        <li><FaEthereum /> Price : <span>10 ETH</span> </li>
                        <li><FaUserAlt /> ID No. : <span>10</span></li>
                        <li><FaTicketAlt /> Raffle : <span>50000</span> </li>
                        <li>
                            <NavLink to={'/winner'}><FaTrophy /> Winner</NavLink>
                        </li>
                    </ul>
                </div>
            </div>

            <div className='register_bg d-flex align-items-center flex-md-row flex-column'>
                <div className='register_img'>
                    <img src={require('../../assets/imgs/10ETH.png')} alt="10ETH" />
                </div>
                <div className='register_content'>
                    <p><FaCalendarAlt /> March 01, 2023, 05:00 a.m.</p>
                    <h5>Registered for 10 ETH Raffle <FaCheckCircle /></h5>
                    <ul>
                        <li><FaWallet /> Wallet : <span>0x5219...c15a</span></li>
                        <li><FaEthereum /> Price : <span>10 ETH</span> </li>
                        <li><FaUserAlt /> ID No. : <span>10</span></li>
                        <li><FaTicketAlt /> Raffle : <span>50000</span> </li>
                        <li>
                            <NavLink to={'/winner'}><FaTrophy /> Winner</NavLink>
                        </li>
                    </ul>
                </div>
            </div>
        </Col>
        
    )
}

export default ActivityRegister;