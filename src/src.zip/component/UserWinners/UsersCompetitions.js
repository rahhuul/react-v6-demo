import React, {} from 'react';
import { NavLink } from 'react-router-dom';
import { Col, Row } from 'react-bootstrap';

import { Card } from 'antd';
import { BsPatchCheckFill } from "react-icons/bs";

const UsersCompetitions = () => {

    return (
        
        <Row>
            <Col className='d-flex' sm="6" md="4" lg="3">
                <Card className='card_box'>
                    <div className='card_heading d-flex align-items-center justify-content-between'>
                        <h6>
                            <NavLink to={"/raffle"}>
                                5 ETH Raffle <BsPatchCheckFill />
                            </NavLink>
                        </h6>
                    </div>
                    <div className='card_img'>
                        <div className="raffleid">
                            <span className="event-nft-id">#10</span>
                        </div>

                        <NavLink to={"/raffle"}>
                            <img src={require('../../assets/imgs/10ETH.png')} alt="10ETH" />
                        </NavLink>

                        <div className="holders_event">
                            <span>Ended 18 hours ago</span>
                        </div>
                    </div>
                    <div className='card_description'>
                        <div className='event-value text-center'>   
                            <h5><span>Value:</span> <img src={require('../../assets/imgs/eth-icon.png')} alt="eth" /> 10</h5>
                        </div>
                        <p className='close-date'>Closed today</p>
                    </div>    
                </Card>
            </Col>
            <Col className='d-flex' sm="6" md="4" lg="3">
                <Card className='card_box'>
                    <div className='card_heading d-flex align-items-center justify-content-between'>
                        <h6>
                            <NavLink to={"/raffle"}>
                                5 ETH Raffle <BsPatchCheckFill />
                            </NavLink>
                        </h6>
                    </div>
                    <div className='card_img'>
                        <div className="raffleid">
                            <span className="event-nft-id">#10</span>
                        </div>

                        <NavLink to={"/raffle"}>
                            <img src={require('../../assets/imgs/10ETH.png')} alt="10ETH" />
                        </NavLink>

                        <div className="holders_event">
                            <span>Ended 2 Days ago</span>
                        </div>
                    </div>
                    <div className='card_description'>
                        <div className='event-value text-center'>   
                            <h5><span>Value:</span> <img src={require('../../assets/imgs/eth-icon.png')} alt="eth" /> 5</h5>
                        </div>
                        <p className='close-date'>Closed: 2 March 2023</p>
                    </div>    
                </Card>
            </Col>
        </Row>
        
    )
}

export default UsersCompetitions;