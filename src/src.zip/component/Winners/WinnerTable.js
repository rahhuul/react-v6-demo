import React from 'react';
import { Col } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';

import { FaEdit } from "react-icons/fa";

const WinnerTable = () => {
    return (

        <Col md="12">
            <div className='table_wrapp'>
                <table width={'100%'}>
                    <thead>
                        <tr>
                            <th>Raffle</th>
                            <th>Winner</th>
                            <th>Prize Value</th>
                            <th>Transaction</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div className='d-flex align-items-center'>
                                    <div className='winner_img'>
                                        <img width={'70'} src={require('../../assets/imgs/10ETH.png')} alt="10ETH" />
                                    </div>
                                    <div className='winner_title'>
                                        <h6>
                                            <NavLink to={''}>10 ETH Raffle</NavLink>
                                        </h6>
                                        <p className='spots'>50000</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div className='winner_user'>
                                    <NavLink to={'/user-winner'}>
                                        <img width={'50'} src={require('../../assets/imgs/user-profile.webp')} alt="user" />
                                    </NavLink>
                                </div>
                            </td>
                            <td>
                                <div className='winner_price'>
                                    <img src={require('../../assets/imgs/eth-icon.png')} alt="eth" /> 
                                    10 ETH
                                </div>
                            </td>
                            <td>
                                <div className='winner_tran'>
                                    <NavLink to={'https://etherscan.io/error'} target={'_blank'}>text <FaEdit /></NavLink>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div className='d-flex align-items-center'>
                                    <div className='winner_img'>
                                        <img width={'70'} src={require('../../assets/imgs/10ETH.png')} alt="10ETH" />
                                    </div>
                                    <div className='winner_title'>
                                        <h6>
                                            <NavLink to={''}>10 ETH Raffle</NavLink>
                                        </h6>
                                        <p className='spots'>50000</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div className='winner_user'>
                                    <NavLink to={'/user-winner'}>
                                        <img width={'50'} src={require('../../assets/imgs/user-profile.webp')} alt="user" />
                                    </NavLink>
                                </div>
                            </td>
                            <td>
                                <div className='winner_price'>
                                    <img src={require('../../assets/imgs/eth-icon.png')} alt="eth" /> 
                                    10 ETH
                                </div>
                            </td>
                            <td>
                                <div className='winner_tran'>
                                    <NavLink to={'https://etherscan.io/error'} target={'_blank'}>text <FaEdit /></NavLink>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div className='d-flex align-items-center'>
                                    <div className='winner_img'>
                                        <img width={'70'} src={require('../../assets/imgs/10ETH.png')} alt="10ETH" />
                                    </div>
                                    <div className='winner_title'>
                                        <h6>
                                            <NavLink to={''}>10 ETH Raffle</NavLink>
                                        </h6>
                                        <p className='spots'>50000</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div className='winner_user'>
                                    <NavLink to={'/user-winner'}>
                                        <img width={'50'} src={require('../../assets/imgs/user-profile.webp')} alt="user" />
                                    </NavLink>
                                </div>
                            </td>
                            <td>
                                <div className='winner_price'>
                                    <img src={require('../../assets/imgs/eth-icon.png')} alt="eth" /> 
                                    10 ETH
                                </div>
                            </td>
                            <td>
                                <div className='winner_tran'>
                                    <NavLink to={'https://etherscan.io/error'} target={'_blank'}>text <FaEdit /></NavLink>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Col>
        
    )
}

export default WinnerTable;