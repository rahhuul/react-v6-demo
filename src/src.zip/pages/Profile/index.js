import React from 'react';

import UserProfile from "../../component/Profile/UserProfile"

const Profile = () => {
    return (

        <>
            <UserProfile />
        </>
        
    )
}

export default Profile;