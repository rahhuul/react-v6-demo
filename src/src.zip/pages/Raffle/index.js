import React from 'react';

import RafflesPage from "../../component/Raffles/RafflesPage"
import Faq from "../../component/Frequently/Faq"

const Raffle = () => {
    return (
        <>
            <RafflesPage />
            <Faq />
        </>

    )
}

export default Raffle;