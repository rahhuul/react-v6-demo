import React from 'react';
import MainPage from '../../component/Homes/MainPage';

const Home = () => {
    return (
        <>
            <MainPage />
        </>
    )
}

export default Home;