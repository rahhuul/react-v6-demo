import React from 'react';

import RaffleEndeds from '../../component/RaffleEnd/RaffleEndeds';

const RaffleEnded = () => {
    return (

        <RaffleEndeds />
        
    )
}

export default RaffleEnded;