import React from 'react';

import UserMain from '../../component/UserWinners/UserMain';

const UserWinner = () => {
    return (

        <UserMain />
        
    )
}

export default UserWinner;