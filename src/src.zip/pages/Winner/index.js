import React from 'react';

import WinnerMain from '../../component/Winners/WinnerMain' 

const Winner = () => {
    return (

        <WinnerMain />
        
    )
}

export default Winner;