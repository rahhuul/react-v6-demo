import React from 'react';

import ActivityMain from '../../component/Activitys/ActivityMain' 

const Activity = () => {
    return (

        <ActivityMain />
        
    )
}

export default Activity;